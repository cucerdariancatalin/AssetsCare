package com.gsabr.assetscare

import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import com.fasterxml.jackson.module.kotlin.*
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.gson.JsonObject
import kotlinx.android.synthetic.main.activity_dados.*
import kotlinx.android.synthetic.main.activity_revisao.*
import kotlinx.android.synthetic.main.activity_revisao.tv_numero_patrimonio
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

import kotlin.reflect.jvm.internal.impl.load.kotlin.JvmType


class RevisaoActivity : AppCompatActivity()
//, AdapterView.OnItemSelectedListener
{

    var date = Calendar.getInstance().time
    lateinit var pecaUtilizada: String
    var dateTimeFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
    var jsonobj = JSONObject()
    lateinit var numOS: String

    val url = "http://192.168.110.239:8080/api_manutencao/api/peca"
    val getOsUrl = "http://192.168.110.239:8080/api_manutencao/api/os"
    val postUrl = "http://192.168.110.239:8080/api_manutencao/api/os"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_revisao)
        //setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT)
        //var patrimonio = intent.getStringExtra("patrimonio")
        //var localizacao = intent.getStringExtra("localizacao")
        //val jsonobj = JSONObject()
        var patrimonio = intent.getStringExtra("patrimonio")
        var localizacao = intent.getStringExtra("localizacao")
        tv_data_os.text = dateTimeFormat.format(date)

        tv_loja.text = localizacao
        tv_numero_patrimonio.text = patrimonio



        objectRequest(url)
        getNumOs(getOsUrl)
//        tv_num_os.text = numOS

        btn_enviar_os.setOnClickListener {
            //postOs(postUrl)
            var tipo_os = ""
            var os_status = ""
            var pos_os = ""

            jsonobj.put("patrimonio", patrimonio)
            jsonobj.put("data_inicio_os", dateTimeFormat.format(date))
            dados_titulo_revisao.text = jsonobj.toString()
            var id = rg_tipos_os.checkedRadioButtonId
            when(id){
                R.id.rd_descricao_tipo1 -> tipo_os = "preventiva"
                R.id.rd_descricao_tipo1 -> tipo_os = "corretiva"
                else -> tipo_os = "não definida"
            }

            jsonobj.put("tipo_os", tipo_os)

            id = rg_os_status.checkedRadioButtonId
            when(id){
                R.id.rd_conclusao_sim -> os_status = "aberta" //Aberta
                R.id.rd_conclusao_nao -> os_status = "fechada" //Fechada
            }

            jsonobj.put("os_status", os_status.toString())

            id = rg_pos_os.checkedRadioButtonId
            when(id){
                R.id.rd_atende -> pos_os = "atende"
                R.id.rd_atende_restrito -> pos_os = "atende"
                R.id.rd_nao_atende -> pos_os = "atende"
            }

            jsonobj.put("pos_os", pos_os)

            jsonobj.put("data_inicio_os", dateTimeFormat.format(date))

            //teste escrevendo no título
            dados_titulo_revisao.text = jsonobj.toString()
        }

    }

    fun getNumOs(url: String){

        val que = Volley.newRequestQueue(this@RevisaoActivity)
        val jsonArrayRequest = JsonArrayRequest(
            Request.Method.GET, url, null,
            { response ->

                //var arrayListOs = arrayListOf<String>()
                for (i in 0..response.length() - 1) {

                    val osJsonObject = response.getJSONObject(i)
                    numOS = osJsonObject.getString("sequencia")
                }
                tv_num_os.text = numOS
                Toast.makeText( applicationContext,"Conexão realizada com Sucesso!", Toast.LENGTH_SHORT).show()
            },
            { error ->
                Toast.makeText( applicationContext,"Erro ao obter número da OS! Verifique a conexão e tente novamente", Toast.LENGTH_SHORT).show()
            }
        )
        que.add(jsonArrayRequest)
    }

    fun objectRequest(url: String) {

        val queue = Volley.newRequestQueue(this@RevisaoActivity)

        val jsonArrayRequest = JsonArrayRequest(
            Request.Method.GET, url, null,
            { response ->

                //val pecaJsonObject = response.getJSONObject(0)

                var arrayListPecas = arrayListOf<String>()
                for (i in 0..response.length() - 1) {

                    val pecaJsonObject = response.getJSONObject(i)
                    val codProd = pecaJsonObject.getString("codprod")
                    val descricao = pecaJsonObject.getString("descricao").toUpperCase()
                    arrayListPecas.add("${codProd}; ${descricao}")

                }
                //val codProd = pecaJsonObject.getString("codprod")
                //val descricao = pecaJsonObject.getString("descricao")

                //val adapterPecas = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_item, arrayListPecas)

                val searchmethod =
                    ArrayAdapter(this, android.R.layout.simple_spinner_item, arrayListPecas)
                searchmethod.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                // spinner_view!!.adapter = searchmethod


                spinnerPecasSearch.setTitle("Selecione a peça:")
                spinnerPecasSearch.setPositiveButton("OK")
                spinnerPecasSearch.adapter = searchmethod

                //val pecaSelecionada = spinnerPecasSearch.onItemSelectedListener.toString()
                //tv_titulo.text = spinnerPecasSearch.selectedItem.toString()
                spinnerPecasSearch.onItemSelectedListener =
                    object : AdapterView.OnItemSelectedListener {
                        override fun onItemSelected(
                            parent: AdapterView<*>,
                            view: View, position: Int, id: Long
                        ) {
                            pecaUtilizada = arrayListPecas[position].substringBefore(";")
                            //Toast.makeText(this@MainActivity,  "" + arrayListPecas[position], Toast.LENGTH_SHORT).show()
                        }
                        override fun onNothingSelected(parent: AdapterView<*>) {
                            // TODO
                        }
                    }
                Toast.makeText(
                    applicationContext,
                    "Conexão realizada com Sucesso!",
                    Toast.LENGTH_SHORT
                ).show()
            },
            { error ->
                Toast.makeText(
                    applicationContext,
                    "Erro, verifique o acesso à rede e tente novamente!",
                    Toast.LENGTH_SHORT
                ).show()
            }
        )
        queue.add(jsonArrayRequest)
    }

    //teste dados (RETIRAR DEPOIS)
    fun testeDados(){

        jsonobj.put("patrimonio", "Teste")

        dados_titulo_revisao.text = jsonobj.toString()
    }
    //

    //Enviar ordem de serviço
    fun postOs(url: String){

        val queue = Volley.newRequestQueue(this@RevisaoActivity)

        jsonobj.put("dados", "teste")


        val jsonObjectRequest = JsonObjectRequest(
            Request.Method.POST, url, jsonobj, { response ->
                Toast.makeText(applicationContext, "Ordem de Serviço Enviada", Toast.LENGTH_SHORT).show()
            }, {
                Toast.makeText(applicationContext, "Erro, verifique a rede tente enviar novamente!", Toast.LENGTH_SHORT).show()
            })
        queue.add(jsonObjectRequest)
    }
}